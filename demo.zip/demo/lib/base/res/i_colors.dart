
import 'dart:ui';

class IColors{
  static const Color colorFFFFFF = Color(0xFFFFFFFF);
}